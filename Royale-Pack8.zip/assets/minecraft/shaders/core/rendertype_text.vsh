#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV2;

uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec2 texCoord0;

// Royale: minimap glyphs are tagged by the server with colours whose low 3 bits are R=5, G=3, B=6.
// They are laid out for a 640-unit wide GUI centred on the screen; move them so the layout hugs the right edge of the real GUI width.
void main() {
    vec3 pos = Position;
    ivec3 c = ivec3(round(Color.rgb * 255.0));
    if ((c.r & 7) == 5 && (c.g & 7) == 3 && (c.b & 7) == 6 && ProjMat[3][3] == 1.0) {
        pos.x += 1.0 / ProjMat[0][0] - 320.0;   // (guiWidth - 640) / 2, guiWidth = 2 / ProjMat[0][0]
    }

    gl_Position = ProjMat * ModelViewMat * vec4(pos, 1.0);

    sphericalVertexDistance = fog_spherical_distance(pos);
    cylindricalVertexDistance = fog_cylindrical_distance(pos);
    vertexColor = Color * texelFetch(Sampler2, UV2 / 16, 0);
    texCoord0 = UV0;
}
